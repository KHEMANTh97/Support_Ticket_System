// shared lists used across components
export const categories = ['billing', 'technical', 'account', 'general'];
export const priorities = ['low', 'medium', 'high', 'critical'];
export const statuses = ['open', 'in_progress', 'resolved', 'closed'];
